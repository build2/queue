void oma(void) {}
